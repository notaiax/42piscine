/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   maff_revalpha.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: exam <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/12 18:35:56 by exam              #+#    #+#             */
/*   Updated: 2019/07/12 19:07:02 by exam             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int 	main(void)
{
	char c;
	int capital_diff;

	c = 'z';
	capital_diff = 'a' - 'A';
	while (c != ('a' - 1))
	{
		write(1, &c, 1);
		c = c - 1 - capital_diff;
		write(1, &c, 1);
		c = c - 1 + capital_diff;
	}
	c = '\n';
	write(1, &c, 1);
	return (0);

}
