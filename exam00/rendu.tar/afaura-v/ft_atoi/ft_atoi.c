/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: exam <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/12 19:18:59 by exam              #+#    #+#             */
/*   Updated: 2019/07/12 19:46:57 by exam             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_atoi(const char *str){
	int res;
	int i;
	int is_negative;

	i = 0;
	res = 0;
	is_negative = 0;
	
	if(*(str) == '-')
	{
		is_negative = 1;
		i = i + 1;	
	}

	res = (*(str + i)) - '0';
	i = i + 1;
	while(*(str + i) != 0){
		res = res * 10;
		res = res + ((*(str + i)) - '0');
		i = i + 1;
	}
	if (is_negative == 1)
	{
		res = res * -1;
	}

	return (res);
}
